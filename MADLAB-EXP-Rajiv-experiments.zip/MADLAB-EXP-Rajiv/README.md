# MAD Lab Flutter Practical Experiments

Source files for the first nine Flutter practicals visible in the provided syllabus screenshot.

## Contents

- `experiments/01_environment_setup.dart` — Environment verification screen (installation commands are below)
- `experiments/02_hello_world.dart` — Hello World
- `experiments/03_common_widgets.dart` — Common widgets
- `experiments/04_interactive_form.dart` — Form and validation
- `experiments/05_layout_widgets.dart` — Layout widgets
- `experiments/06_icons_images_charts.dart` — Icons, network image and bar chart
- `experiments/07_navigation_routing_gestures.dart` — Named routes and gestures
- `experiments/08_file_handling.dart` — Read/write a private app file
- `experiments/09_firebase_firestore.dart` — Firebase Cloud Firestore

## Run any experiment

Each `.dart` file is a standalone `main.dart` source file. Create a Flutter project, copy the chosen file into that project's `lib/main.dart`, then run the app:

```bash
flutter create my_experiment
cd my_experiment
# Replace lib/main.dart with the chosen source file
flutter pub get
flutter run
```

## Environment setup (Experiment 1)

Install Flutter SDK and Android Studio / Android SDK. Then run:

```bash
flutter --version
flutter doctor
flutter doctor --android-licenses
flutter devices
```

## Extra dependencies

Experiment 8:

```bash
flutter pub add path_provider
```

Experiment 9:

```bash
flutter pub add firebase_core
flutter pub add cloud_firestore
firebase login
dart pub global activate flutterfire_cli
flutterfire configure
```

The Firebase setup generates `lib/firebase_options.dart`; keep that generated file in the Flutter project. Enable Cloud Firestore in Firebase Console and configure secure Firestore rules. Do not use unrestricted public read/write rules in production.

## Notes

- Experiment 6's image requires internet access. Its chart values are illustrative.
- Experiment 9 requires a real Firebase project and configuration before it can run.
- The provided screenshot cuts off during Experiment 10, so this bundle contains only Experiments 1–9 that were readable.
